Agenda:
Why should we use express?
Why Nodemon?
Installing Express@4
Request parameters and queries
Static Files